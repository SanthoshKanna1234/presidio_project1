import json
import os
from datetime import datetime

class Teacher:
    def __init__(self, full_name, age, dob, num_classes):
        self.full_name = full_name
        self.age = age
        self.dob = dob
        self.num_classes = num_classes

class TeacherManagementSystem:
    def __init__(self):
        self.teachers = []
        self.teachers_file = "teachers.json"

        # Load teachers from file if the file exists
        if os.path.exists(self.teachers_file):
            with open(self.teachers_file, "r") as file:
                data = json.load(file)
                for teacher_data in data:
                    teacher = Teacher(**teacher_data)
                    self.teachers.append(teacher)
    
    def add_teacher(self):
        print("\nAdd a Teacher:")

        while True:
            full_name = input("Enter full name: ")
            if len(full_name.strip()) > 0:
                break
            else:
                print("Please enter a valid name.")

        while True:
            try:
                age = int(input("Enter age: "))
                if age > 0:
                    break
                else:
                    print("Please enter a valid age (greater than 0).")
            except ValueError:
                print("Invalid input. Please enter a valid age.")

        while True:
            dob = input("Enter date of birth (YYYY-MM-DD): ")
            try:
                datetime.strptime(dob, "%Y-%m-%d")
                break
            except ValueError:
                print("Invalid date format. Please enter date in YYYY-MM-DD format.")

        while True:
            try:
                num_classes = int(input("Enter number of classes: "))
                if num_classes >= 0:
                    break
                else:
                    print("Please enter a valid number of classes (non-negative).")
            except ValueError:
                print("Invalid input. Please enter a valid number.")

        new_teacher = Teacher(full_name, age, dob, num_classes)
        self.teachers.append(new_teacher)
        self.save_teachers_to_file()
        print("Teacher added successfully!")

    def save_teachers_to_file(self):
        with open(self.teachers_file, "w") as file:
            data = [teacher.__dict__ for teacher in self.teachers]
            json.dump(data, file, indent=4)

    def filter_by_age(self):
        print("\nFilter Teachers by Age:")
        while True:
            try:
                age_criteria = int(input("Enter age criteria: "))
                break
            except ValueError:
                print("Invalid input. Please enter a valid age.")

        while True:
            print("Select filter condition:")
            print("1. Greater than or equal to")
            print("2. Less than")
            try:
                condition = int(input("Enter your choice: "))
                if condition in (1, 2):
                    break
                else:
                    print("Invalid choice. Please enter 1 or 2.")
            except ValueError:
                print("Invalid input. Please enter a valid choice.")

        if condition == 1:
            filtered_teachers = [teacher for teacher in self.teachers if teacher.age >= age_criteria]
        else:
            filtered_teachers = [teacher for teacher in self.teachers if teacher.age < age_criteria]

        self.show_all_teachers(filtered_teachers)

    def show_all_teachers(self, teachers=None):
        print("\nAll Teachers:")
        teachers_to_display = teachers if teachers else self.teachers

        if not teachers_to_display:
            print("No teachers found.")
        else:
            for idx, teacher in enumerate(teachers_to_display, start=1):
                print(f"{idx}. {teacher.full_name} | Age: {teacher.age} | DOB: {teacher.dob} | Classes: {teacher.num_classes}")





    def filter_by_classes(self):
        print("\nFilter Teachers by Number of Classes:")
        while True:
            try:
                class_criteria = int(input("Enter class criteria: "))
                break
            except ValueError:
                print("Invalid input. Please enter a valid number of classes.")

        while True:
            print("Select filter condition:")
            print("1. Greater than or equal to")
            print("2. Less than")
            print("3. Equal to")
            try:
                condition = int(input("Enter your choice: "))
                if condition in (1, 2, 3):
                    break
                else:
                    print("Invalid choice. Please enter 1, 2, or 3.")
            except ValueError:
                print("Invalid input. Please enter a valid choice.")

        if condition == 1:
            filtered_teachers = [teacher for teacher in self.teachers if teacher.num_classes >= class_criteria]
        elif condition == 2:
            filtered_teachers = [teacher for teacher in self.teachers if teacher.num_classes < class_criteria]
        else:
            filtered_teachers = [teacher for teacher in self.teachers if teacher.num_classes == class_criteria]

        self.show_all_teachers(filtered_teachers)


    def search_teacher(self):
        print("\nSearch for a Teacher:")
        search_name = input("Enter teacher's full name: ")

        if search_name.strip():  # Check if input is not empty
            found_teachers = [teacher for teacher in self.teachers if search_name.lower() in teacher.full_name.lower()]
            if found_teachers:
                self.show_all_teachers(found_teachers)
            else:
                print("No matching teachers found.")
        else:
            print("Please enter a valid teacher's name.")

    def update_teacher(self):
        print("\nUpdate Teacher's Record:")
        print("Select the category to update:")
        print("1. Full Name")
        print("2. Age")
        print("3. Date of Birth")
        print("4. Number of Classes")
        
        try:
            category_choice = int(input("Enter the number of the category to match: "))
            if category_choice == 1:
                update_name = input("Enter the full name of the teacher to update: ")

                found_teacher = None
                for teacher in self.teachers:
                    if teacher.full_name.lower() == update_name.lower():
                        found_teacher = teacher
                        break

                if found_teacher:
                    print("Teacher found.")
                    print("Update specific details for the teacher:")
                    print("1. Full Name")
                    print("2. Age")
                    print("3. Date of Birth")
                    print("4. Number of Classes")

                    try:
                        detail_choice = int(input("EEnter the choice: "))
                        if detail_choice == 1:
                            new_full_name = input("Enter new full name: ")
                            if len(new_full_name.strip()) > 0:
                                found_teacher.full_name = new_full_name
                                print("Full Name updated successfully!")
                                self.save_teachers_to_file()
                            else:
                                print("Please enter a valid name.")
                        elif detail_choice == 2:
                            new_age = int(input("Enter new age: "))
                            if new_age > 0:
                                found_teacher.age = new_age
                                print("Age updated successfully!")
                                self.save_teachers_to_file()
                            else:
                                print("Please enter a valid age (greater than 0).")
                        elif detail_choice == 3:
                            new_dob = input("Enter new date of birth (YYYY-MM-DD): ")
                            try:
                                datetime.strptime(new_dob, "%Y-%m-%d")
                                found_teacher.dob = new_dob
                                print("Date of Birth updated successfully!")
                                self.save_teachers_to_file()
                            except ValueError:
                                print("Invalid date format. Please enter date in YYYY-MM-DD format.")
                        elif detail_choice == 4:
                            new_num_classes = int(input("Enter new number of classes: "))
                            if new_num_classes >= 0:
                                found_teacher.num_classes = new_num_classes
                                print("Number of Classes updated successfully!")
                                self.save_teachers_to_file()
                            else:
                                print("Please enter a valid number of classes (non-negative).")
                        else:
                            print("Invalid detail choice.")
                        self.save_teachers_to_file()
                    except ValueError:
                        print("Invalid input. Please enter a valid choice.")
                else:
                    print("Teacher not found or invalid name.")
                    
            elif category_choice == 2:
                update_age = int(input("Enter new age: "))
                found_teacher=None
                for teacher in self.teachers:
                    if teacher.age == update_age:
                        found_teacher=teacher
                        break
                    

                if found_teacher:
                    print("Teacher's age found.")
                    print("Update specific details for the teacher:")
                    print("1. Full Name")
                    print("2. Age")
                    print("3. Date of Birth")
                    print("4. Number of Classes")

                    try:
                        detail_choice = int(input("Enter the choice: "))
                        if detail_choice == 1:
                            new_full_name = input("Enter new full name: ")
                            if len(new_full_name.strip()) > 0:
                                found_teacher.full_name = new_full_name
                                print("Full Name updated successfully!")
                                self.save_teachers_to_file()
                            else:
                                print("Please enter a valid name.")
                        elif detail_choice == 2:
                            new_age = int(input("Enter new age: "))
                            if new_age > 0:
                                found_teacher.age = new_age
                                print("Age updated successfully!")
                                self.save_teachers_to_file()
                            else:
                                print("Please enter a valid age (greater than 0).")
                        elif detail_choice == 3:
                            new_dob = input("Enter new date of birth (YYYY-MM-DD): ")
                            try:
                                datetime.strptime(new_dob, "%Y-%m-%d")
                                found_teacher.dob = new_dob
                                print("Date of Birth updated successfully!")
                                self.save_teachers_to_file()
                            except ValueError:
                                print("Invalid date format. Please enter date in YYYY-MM-DD format.")
                        elif detail_choice == 4:
                            new_num_classes = int(input("Enter new number of classes: "))
                            if new_num_classes >= 0:
                                found_teacher.num_classes = new_num_classes
                                print("Number of Classes updated successfully!")
                                self.save_teachers_to_file()
                            else:
                                print("Please enter a valid number of classes (non-negative).")
                        else:
                            print("Invalid detail choice.")
                        self.save_teachers_to_file()
                    except ValueError:
                        print("Invalid input. Please enter a valid choice.")
                else:
                    print("Teacher not found or invalid age.")
            
            elif category_choice == 3:
                update_dob = input("Enter new date of birth (YYYY-MM-DD): ")
                found_teacher=None
                datetime.strptime(update_dob, "%Y-%m-%d")
                for teacher in self.teachers:
                    if teacher.dob == update_dob:
                        found_teacher=teacher
                        break
        
                
                if found_teacher:
                    print("Teacher's dob found.")
                    print("Update specific details for the teacher:")
                    print("1. Full Name")
                    print("2. Age")
                    print("3. Date of Birth")
                    print("4. Number of Classes")

                    try:
                        detail_choice = int(input("Enter the choice: "))
                        if detail_choice == 1:
                            new_full_name = input("Enter new full name: ")
                            if len(new_full_name.strip()) > 0:
                                found_teacher.full_name = new_full_name
                                print("Full Name updated successfully!")
                                self.save_teachers_to_file()
                            else:
                                print("Please enter a valid name.")
                        elif detail_choice == 2:
                            new_age = int(input("Enter new age: "))
                            if new_age > 0:
                                found_teacher.age = new_age
                                print("Age updated successfully!")
                                self.save_teachers_to_file()
                            else:
                                print("Please enter a valid age (greater than 0).")
                        elif detail_choice == 3:
                            new_dob = input("Enter new date of birth (YYYY-MM-DD): ")
                            try:
                                datetime.strptime(new_dob, "%Y-%m-%d")
                                found_teacher.dob = new_dob
                                print("Date of Birth updated successfully!")
                                self.save_teachers_to_file()
                            except ValueError:
                                print("Invalid date format. Please enter date in YYYY-MM-DD format.")
                        elif detail_choice == 4:
                            new_num_classes = int(input("Enter new number of classes: "))
                            if new_num_classes >= 0:
                                found_teacher.num_classes = new_num_classes
                                print("Number of Classes updated successfully!")
                                self.save_teachers_to_file()
                            else:
                                print("Please enter a valid number of classes (non-negative).")
                        else:
                            print("Invalid detail choice.")
                        self.save_teachers_to_file()
                    except ValueError:
                        print("Invalid input. Please enter a valid choice.")
                else:
                    print("Teacher not found or invalid DOB.")
                    
            elif category_choice == 4:
                update_class = int(input("Enter new class: "))
                found_teacher=None
                for teacher in self.teachers:
                    if teacher.num_classes == update_class:
                        found_teacher=teacher
                        break

                if found_teacher:
                    print("Teacher's class found.")
                    print("Update specific details for the teacher:")
                    print("1. Full Name")
                    print("2. Age")
                    print("3. Date of Birth")
                    print("4. Number of Classes")

                    try:
                        detail_choice = int(input("Enter the choice: "))
                        if detail_choice == 1:
                            new_full_name = input("Enter new full name: ")
                            if len(new_full_name.strip()) > 0:
                                found_teacher.full_name = new_full_name
                                print("Full Name updated successfully!")
                                self.save_teachers_to_file()
                            else:
                                print("Please enter a valid name.")
                        elif detail_choice == 2:
                            new_age = int(input("Enter new age: "))
                            if new_age > 0:
                                found_teacher.age = new_age
                                print("Age updated successfully!")
                                self.save_teachers_to_file()
                            else:
                                print("Please enter a valid age (greater than 0).")
                        elif detail_choice == 3:
                            new_dob = input("Enter new date of birth (YYYY-MM-DD): ")
                            try:
                                datetime.strptime(new_dob, "%Y-%m-%d")
                                found_teacher.dob = new_dob
                                print("Date of Birth updated successfully!")
                                self.save_teachers_to_file()
                            except ValueError:
                                print("Invalid date format. Please enter date in YYYY-MM-DD format.")
                        elif detail_choice == 4:
                            new_num_classes = int(input("Enter new number of classes: "))
                            if new_num_classes >= 0:
                                found_teacher.num_classes = new_num_classes
                                print("Number of Classes updated successfully!")
                                self.save_teachers_to_file()
                            else:
                                print("Please enter a valid number of classes (non-negative).")
                        else:
                            print("Invalid detail choice.")
                        self.save_teachers_to_file()
                    except ValueError:
                        print("Invalid input. Please enter a valid choice.")
                else:
                    print("Teacher not found or invalid class.")
            
            else:
                print("Invalid category choice.")
        except ValueError:
            print("Invalid input. Please enter a valid choice.")
        

        

    def save_teachers_to_file(self):
        with open(self.teachers_file, "w") as file:
            data = [teacher.__dict__ for teacher in self.teachers]
            json.dump(data, file, indent=4)

    def delete_teacher(self):
        print("\nDelete Teacher's Record:")
        print("Select the category to Delete:")
        print("1. Full Name")
        print("2. Age")
        print("3. Date of Birth")
        print("4. Number of Classes")
        
        try:
            category_choice = int(input("Enter the number of the category to match: "))
            if category_choice == 1:
                delete_name = input("Enter the full name of the teacher to delete: ")

                found_teacher = None
                for teacher in self.teachers:
                    if teacher.full_name.lower() == delete_name.lower():
                        found_teacher = teacher
                        break

                if found_teacher:
                    print("Teacher found.")
                    print("Select the category to delete:")
                    print("1. Full Name")
                    print("2. Age")
                    print("3. Date of Birth")
                    print("4. Number of Classes")

                    try:
                        category_choice = int(input("Enter the number of the category to delete: "))
                        if category_choice == 1:
                            found_teacher.full_name = ""
                            print("Full Name deleted successfully!")
                        elif category_choice == 2:
                            found_teacher.age = None
                            print("Age deleted successfully!")
                        elif category_choice == 3:
                            found_teacher.dob = ""
                            print("Date of Birth deleted successfully!")
                        elif category_choice == 4:
                            found_teacher.num_classes = None
                            print("Number of Classes deleted successfully!")
                        else:
                            print("Invalid category choice.")

                        # Save changes to the file
                        self.save_teachers_to_file()
                    except ValueError:
                        print("Invalid input. Please enter a valid choice.")
                else:
                    print("Teacher not found or invalid name.")
        
            
            elif category_choice == 2:
                delete_age = int(input("Enter new age: "))
                found_teacher=None
                for teacher in self.teachers:
                    if teacher.age == delete_age:
                        found_teacher=teacher
                        break
                    
                if found_teacher:
                    print("Teacher found.")
                    print("Select the category to delete:")
                    print("1. Full Name")
                    print("2. Age")
                    print("3. Date of Birth")
                    print("4. Number of Classes")

                    try:
                        category_choice = int(input("Enter the number of the category to delete: "))
                        if category_choice == 1:
                            found_teacher.full_name = ""
                            print("Full Name deleted successfully!")
                        elif category_choice == 2:
                            found_teacher.age = None
                            print("Age deleted successfully!")
                        elif category_choice == 3:
                            found_teacher.dob = ""
                            print("Date of Birth deleted successfully!")
                        elif category_choice == 4:
                            found_teacher.num_classes = None
                            print("Number of Classes deleted successfully!")
                        else:
                            print("Invalid category choice.")

                        # Save changes to the file
                        self.save_teachers_to_file()
                    except ValueError:
                        print("Invalid input. Please enter a valid choice.")
                else:
                    print("Teacher not found or invalid name.")
            
            elif category_choice == 3:
                delete_dob = input("Enter new date of birth (YYYY-MM-DD): ")
                found_teacher=None
                datetime.strptime(update_dob, "%Y-%m-%d")
                for teacher in self.teachers:
                    if teacher.dob == delete_dob:
                        found_teacher=teacher
                        break
                
                if found_teacher:
                    print("Teacher found.")
                    print("Select the category to delete:")
                    print("1. Full Name")
                    print("2. Age")
                    print("3. Date of Birth")
                    print("4. Number of Classes")

                    try:
                        category_choice = int(input("Enter the number of the category to delete: "))
                        if category_choice == 1:
                            found_teacher.full_name = ""
                            print("Full Name deleted successfully!")
                        elif category_choice == 2:
                            found_teacher.age = None
                            print("Age deleted successfully!")
                        elif category_choice == 3:
                            found_teacher.dob = ""
                            print("Date of Birth deleted successfully!")
                        elif category_choice == 4:
                            found_teacher.num_classes = None
                            print("Number of Classes deleted successfully!")
                        else:
                            print("Invalid category choice.")

                        # Save changes to the file
                        self.save_teachers_to_file()
                    except ValueError:
                        print("Invalid input. Please enter a valid choice.")
                else:
                    print("Teacher not found or invalid name.")
                    
            elif category_choice == 4:
                delete_class = int(input("Enter new class: "))
                found_teacher=None
                for teacher in self.teachers:
                    if teacher.num_classes == delete_class:
                        found_teacher=teacher
                        break
                if found_teacher:
                    print("Teacher found.")
                    print("Select the category to delete:")
                    print("1. Full Name")
                    print("2. Age")
                    print("3. Date of Birth")
                    print("4. Number of Classes")

                    try:
                        category_choice = int(input("Enter the number of the category to delete: "))
                        if category_choice == 1:
                            found_teacher.full_name = ""
                            print("Full Name deleted successfully!")
                        elif category_choice == 2:
                            found_teacher.age = None
                            print("Age deleted successfully!")
                        elif category_choice == 3:
                            found_teacher.dob = ""
                            print("Date of Birth deleted successfully!")
                        elif category_choice == 4:
                            found_teacher.num_classes = None
                            print("Number of Classes deleted successfully!")
                        else:
                            print("Invalid category choice.")

                        # Save changes to the file
                        self.save_teachers_to_file()
                    except ValueError:
                        print("Invalid input. Please enter a valid choice.")
                else:
                    print("Teacher not found or invalid name.")
            else:
                print("Invalid category choice.")
        except ValueError:
            print("Invalid input. Please enter a valid choice.")
                

    def display_average_classes(self):
        total_classes = sum(teacher.num_classes for teacher in self.teachers)
        if total_classes > 0:
            average = total_classes / len(self.teachers)
            print(f"\nAverage number of classes taken by teachers: {average}")
        else:
            print("\nNo teachers or classes found to calculate average.")

def main():
    tms = TeacherManagementSystem()

    while True:
        print("\nTeacher Management System")
        print("1. Show all teachers")
        print("2. Add a teacher")
        print("3. Filter teachers by age")
        print("4. Filter teachers by number of classes")
        print("5. Search for a teacher")
        print("6. Update a teacher's record")
        print("7. Delete a teacher")
        print("8. Display average number of classes")
        print("9. Exit")

        choice = input("Enter your choice: ")

        if choice == "1":
            tms.show_all_teachers()
        elif choice == "2":
            tms.add_teacher()
        elif choice == "3":
            tms.filter_by_age()
        elif choice == "4":
            tms.filter_by_classes()
        elif choice == "5":
            tms.search_teacher()
        elif choice == "6":
            tms.update_teacher()
        elif choice == "7":
            tms.delete_teacher()
        elif choice == "8":
            tms.display_average_classes()
        elif choice == "9":
            print("Exiting...")
            break
        else:
            print("Invalid choice. Please choose a valid option.")

if __name__ == "__main__":
    main()
